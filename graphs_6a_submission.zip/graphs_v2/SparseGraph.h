// SparseGraph.h
#ifndef SPARSEGRAPH_H
#define SPARSEGRAPH_H

#include <vector>
#include "Graph.h"

class SparseGraph : public Graph {
public:

    			SparseGraph	();
    			SparseGraph	(int V, int E);
    			SparseGraph	(Graph * graph);
    			~SparseGraph	();

    SparseGraph& 	operator=	(Graph * graph);
    bool 		isEdge		(int v1, int v2);
    int 		getWeight	(int v1, int v2);
    void 		insertEdge	(int v1, int v2, int w);
	friend istream& operator >> ( istream& input, Graph * graph)
	{
	}
   friend ostream& operator << ( ostream& os, Graph * graph)
   {
   }
private:
    struct AdjacencyListNode {
        int vertex;
        int weight;

        AdjacencyListNode(int v, int w) : vertex(v), weight(w) 
        {
        }
    };

    std::vector<std::vector<AdjacencyListNode>> list; // Adjacency list
};

#endif // SPARSEGRAPH_H
